<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- <link rel="shortcut icon" href="assets/ico/favicon.png"> -->

    <title><?php echo $this->config->item('website_name');?> | Reset Account Password</title>

    <!-- Icons -->
    <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/simple-line-icons.css" rel="stylesheet">

    <!-- Main styles for this application -->
    <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">

</head>

<body class="app flex-row align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card-group mb-0">
                    <div class="card p-4">
                        <div class="card-block">
                            <h5 class="text-center">Reset Password</h5>
                            <hr>
                            <p class="text-muted text-center">Enter your registered email address</p>
                            <span id="form_message"></span>
                            <form id="gen_form" method="post" action="<?php echo reset_url();?>">
	                            <div class="input-group mb-3">
	                                <span class="input-group-addon"><i class="icon-envelope"></i>
	                                </span>
	                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
	                                <input type="hidden" name="form_name" value="reset_request">
	                                <input name="email" type="email" class="form-control" placeholder="Enter your email address" required>
	                            </div>
	                            <div class="row">
	                                <div class="col-6">
	                                    <button id="gen_submit" type="submit" class="btn btn-primary px-4">Reset</button>
	                                </div>
                                    <div class="col-6 text-right">
                                        <a href="<?php echo login_url();?>" class="btn btn-link px-0">Back to Login</a>
                                    </div>
	                            </div>
	                           </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap and necessary plugins -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/tether/dist/js/tether.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/custom.js"></script>
	<script>
		$('#resend_div').hide();
		setTimeout(function(){$('#resend_div').show()}, 30000);
		$(document).on('click', '.resend_auth_code', function() {
			$('#resend_div').hide();
			setTimeout(function(){$('#resend_div').show()}, 30000);
			$.get('<?php echo verify_url('resend');?>');
		});
	</script>
</body>

</html>