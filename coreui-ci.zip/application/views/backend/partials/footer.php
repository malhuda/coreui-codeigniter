	<footer class="app-footer">
     <span class="float-right">&copy; <?php echo date('Y');?> <a href="<?php echo base_url();?>"><?php echo get_setting('website_name');?></a>
     </span>
    </footer>

    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.2.3/jquery-confirm.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/tether/dist/js/tether.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/pace/pace.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/app.js"></script>
    <!-- Custom scripts required by this view -->
    <script src="<?php echo base_url();?>assets/js/custom.js"></script>
    <script src="<?php echo base_url();?>assets/js/bdt.js"></script>
    <?php if($this->session->flashdata('flash_msg')):?>
    <script>
        $.alert({
            title: false,
            draggable: true,
            alignMiddle: true,
            offsetTop: 200,
            content: '<?php $this->session->flashdata('flash_msg');?>',
        });
    </script>
    <?php endif;?>
    <script>
        $(document).ready( function () {
            $('#bootstrap-table').bdt();
        });
    </script>