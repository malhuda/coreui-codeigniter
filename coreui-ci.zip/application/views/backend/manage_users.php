<html lang="en">
<?php $this->load->view('backend/partials/head');?>
<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
    <?php $this->load->view('backend/partials/header');?>
    <div class="app-body">
        <div class="sidebar">
           <?php $this->load->view('backend/partials/sidebar');?>
        </div>
        <!-- Main content -->
        <main class="main">
            <!-- Breadcrumb -->
            <?php $this->load->view('backend/partials/breadcrumb');?>

            <div class="container-fluid">
            <h5>Manage Users <span class="pull-right"><a href="<?php echo admin_url('add-user');?>"><button class="btn btn-info btn-sm">Add <i class="fa fa-plus-square"></i></button></a><button data-url="<?php echo site_url('admin/delete_all_users');?>" id="delete_all_users" class="btn btn-danger btn-sm">Delete All <i class="fa fa-trash"></i></button></span></h5>
            <hr>
            <?php if($users):?>
            	<?php $this->load->view('backend/profiles/users', array('users' => $users));?>
            <?php else:?>
            	<h1 style="margin-top:10%;" class="text-center text-muted">No users found! <span style="cursor: pointer">Add <i class="fa fa-plus-square"></i></span></h1>
            <?php endif;?>
            </div>
            <!-- /.conainer-fluid -->
        </main>
    </div>
    <?php $this->load->view('backend/partials/footer');?>
</body>
</html>