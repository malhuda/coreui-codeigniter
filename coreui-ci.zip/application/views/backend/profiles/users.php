				<table class="table table-hover" id="bootstrap-table">
                <thead>
                <tr>
                    <th>#ID</th>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Reg. Date</th>
                    <th class="disable-sorting"></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($users as $u):?>
                <tr id="user-<?php echo $u->id;?>" <?php if($u->id != $user->id):?> class="other-users"<?php endif;?>>
                    <td><?php echo $u->id;?></td>
                    <td><?php echo $u->first_name . ' ' . $u->last_name;?></td>
                    <td><?php echo role_name_by_id($u->role);?></td>
                    <td><?php echo $u->email;?></td>
                    <td><?php echo $u->is_active ? '<span class="text-success">Active <i class="fa fa-check-circle"></i></span>' : '<span class="text-warning">Inactive <i class="fa fa-info-circle"></i></span>';?></td>
                    <td><?php echo date('M d, Y', strtotime($u->created_on));?></td>
                    <td class="text-right">
                    	<a href="<?php echo site_url('admin/profile/'.$u->id);?>" class="text-info">Edit</a><?php if($u->id != $user->uid):?> |
                    	<span data-url="<?php echo admin_url('delete_all_users/'.$u->id);?>" data-id="<?php echo $u->id;?>" class="deleteuser cursor-pointer text-danger">Delete</span><?php endif;?>
                    </td>
                </tr>
             	<?php endforeach;?>
                </tbody>
            </table>