<div class="col-sm-12">
	<div class="card">
		<div class="card-block">
			<form id="gen_form" method="post" action="<?php echo admin_url('profile');?>">
				<h4>Edit <?php echo ($myself == true) ? ' Your ' : $profile->first_name . '\'s ';?> Profile <i class="fa fa-user pull-right"></i></h4>
				<hr>
				<div class="row">
					<div class="form-group col-md-6">
						<label>First Name</label>
						<input id="csrf_token" type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
						<input type="hidden" name="user_id" value="<?php echo $profile->uid;?>">
						<input type="text" name="first_name" class="form-control" placeholder="First name" value="<?php echo $profile->first_name;?>">
					</div>
					<div class="form-group col-md-6">
						<label>Last Name</label>
						<input type="text" name="last_name" class="form-control" placeholder="Last name" value="<?php echo $profile->last_name;?>">
					</div>
					<div class="form-group col-md-6">
						<label>Email</label>
						<input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo $profile->email;?>">
					</div>
					<div class="form-group col-md-6">
						<label>Mobile Number</label>
						<input type="text" name="mobile_number" class="form-control" placeholder="Mobile number" value="<?php echo $profile->mobile_number;?>">
					</div>
					<?php if(!$myself):?>
					<div class="form-group col-md-6">
						<label>User Role</label>
						<select class="form-control" name="role" required>
							<?php if(is_array($roles)): foreach($roles as $role):?>
								<option value="<?php echo $role->id;?>"<?php if($role->id == $profile->rid):?> selected<?php endif;?>><?php echo $role->role_name;?></option>
							<?php endforeach; else:?>
							<option value="" class="disabled">No roles found</option>
							<?php endif;?>
						</select>
					</div>
					<div class="form-group col-md-6">
						<label>User Status</label>
						<select class="form-control" name="is_active" required>
							<option value="1">Active</option>
							<option value="0"<?php if(!$profile->is_active):?> selected<?php endif;?>>Inactive</option>
						</select>
					</div>
					<?php endif;?>
					<div class="form-group col-md-12">
						<label>Bio Info</label>
						<textarea rows="4" class="form-control" name="bio" placeholder="Brief profile biography (Optional)"><?php echo $profile->bio;?></textarea>
					</div>
					<?php if($myself == true):?>
					<div class="form-group col-md-12">
						<label>New Password</label>
						<input type="password" name="password" class="form-control" placeholder="Provide only if you want to change your account password" autocomplete="new-password">
					</div>
					<?php endif;?>
					<div class="col-md-12" id="form_message"></div>
					<div class="form-group col-md-12 text-right">
						<?php if($myself == false):?>
						<button data-name="<?php echo $profile->first_name;?>" data-url="<?php echo reset_url();?>" data-email="<?php echo $profile->email;?>" data-token="<?php echo $this->security->get_csrf_token_name();?>" type="button" id="user_reset_pass" class="btn btn-warning">Reset Password</button>
						<?php endif;?>
						<button id="gen_submit" class="btn btn-info">Save Settings</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>