<div class="col-sm-12">
	<div class="card">
		<div class="card-block">
			<form method="post" class="settings_form" action="<?php echo admin_url('settings');?>">
				<h6>General Settings <i class="fa fa-cog pull-right"></i></h6>
				<hr>
				<div class="row">
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
					<?php $settings = get_all_settings('general'); if($settings): foreach($settings as $setting): if(show_setting($setting->setting_name)):?>
					<div class="form-group col-sm-6">
						<label><?php echo strtoupper(str_replace('_', ' ', $setting->setting_name));?> <?php if($setting->description):?><i data-toggle="tooltip" title="<?php echo $setting->description;?>" class="fa fa-info-circle text-info"></i><?php endif;?></label>
						<?php if($setting->type == 'input'):?>
						<input name="<?php echo $setting->setting_name;?>" type="text" class="form-control" placeholder="<?php echo strtoupper(str_replace('_', ' ', $setting->setting_name));?>" value="<?php echo $setting->setting_value;?>">
						<?php elseif($setting->type == 'select'):?>
						<select name="<?php echo $setting->setting_name;?>" class="selch form-control">
						<?php $options = explode('|', $setting->options); foreach($options as $option):?>
							<option value="<?php echo $option;?>"<?php if($option == $setting->setting_value):?> selected<?php endif;?>><?php echo ucfirst($option);?></option>
						<?php endforeach;?>
						</select>
						<?php endif;?>
					</div>
					<?php endif; endforeach; endif;?>
				</div>
				<br>
				<h6>Security Settings <i class="fa fa-lock pull-right"></i></h6>
				<hr>
				<div class="row">
					<?php $settings = get_all_settings('security'); if($settings): foreach($settings as $setting): if(show_setting($setting->setting_name)):?>
					<div class="form-group col-sm-6">
						<label><?php echo strtoupper(str_replace('_', ' ', $setting->setting_name));?> <?php if($setting->description):?><i data-toggle="tooltip" title="<?php echo $setting->description;?>" class="fa fa-info-circle text-info"></i><?php endif;?></label>
						<?php if($setting->type == 'input'):?>
						<input name="<?php echo $setting->setting_name;?>" type="text" class="form-control" placeholder="<?php echo strtoupper(str_replace('_', ' ', $setting->setting_name));?>" value="<?php echo $setting->setting_value;?>">
						<?php elseif($setting->type == 'select'):?>
						<select name="<?php echo $setting->setting_name;?>" class="selch form-control">
						<?php $options = explode('|', $setting->options); foreach($options as $option):?>
							<option value="<?php echo $option;?>"<?php if($option == $setting->setting_value):?> selected<?php endif;?>><?php echo ucfirst($option);?></option>
						<?php endforeach;?>
						</select>
						<?php endif;?>
					</div>
					<?php endif; endforeach; endif;?>
				</div>
				<br>
				<h6>User Registration <i class="fa fa-user pull-right"></i></h6>
				<hr>
				<div class="row">
					<?php $settings = get_all_settings('user_registration'); if($settings): foreach($settings as $setting): if(show_setting($setting->setting_name)):?>
					<div class="form-group col-sm-6">
						<label><?php echo strtoupper(str_replace('_', ' ', $setting->setting_name));?> <?php if($setting->description):?><i data-toggle="tooltip" title="<?php echo $setting->description;?>" class="fa fa-info-circle text-info"></i><?php endif;?></label>
						<?php if($setting->type == 'input'):?>
						<input name="<?php echo $setting->setting_name;?>" type="text" class="form-control" placeholder="<?php echo strtoupper(str_replace('_', ' ', $setting->setting_name));?>" value="<?php echo $setting->setting_value;?>">
						<?php elseif($setting->type == 'select'):?>
						<select name="<?php echo $setting->setting_name;?>" class="selch form-control">
						<?php $options = explode('|', $setting->options); foreach($options as $option):?>
							<option value="<?php echo $option;?>"<?php if($option == $setting->setting_value):?> selected<?php endif;?>><?php echo ucfirst($option);?></option>
						<?php endforeach;?>
						</select>
						<?php endif;?>
					</div>
					<?php endif; endforeach; endif;?>
				</div>
				<br>
				<h6>Communication Settings <i class="fa fa-envelope pull-right"></i></h6>
				<hr>
				<div class="row">
					<?php $settings = get_all_settings('communication'); if($settings): foreach($settings as $setting): if(show_setting($setting->setting_name)):?>
					<div class="form-group col-sm-6">
						<label><?php echo strtoupper(str_replace('_', ' ', $setting->setting_name));?> <?php if($setting->description):?><i data-toggle="tooltip" title="<?php echo $setting->description;?>" class="fa fa-info-circle text-info"></i><?php endif;?></label>
						<?php if($setting->type == 'input'):?>
						<input name="<?php echo $setting->setting_name;?>" type="text" class="form-control" placeholder="<?php echo strtoupper(str_replace('_', ' ', $setting->setting_name));?>" value="<?php echo $setting->setting_value;?>">
						<?php elseif($setting->type == 'select'):?>
						<select name="<?php echo $setting->setting_name;?>" class="selch form-control">
						<?php $options = explode('|', $setting->options); foreach($options as $option):?>
							<option value="<?php echo $option;?>"<?php if($option == $setting->setting_value):?> selected<?php endif;?>><?php echo ucfirst($option);?></option>
						<?php endforeach;?>
						</select>
						<?php endif;?>
					</div>
					<?php endif; endforeach; endif;?>
				</div>
				<hr>
				<button class="submitbtn btn btn-info pull-right">Save Settings</button>
			</form>
		</div>
	</div>
</div>