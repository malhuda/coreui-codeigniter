<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- <link rel="shortcut icon" href="assets/ico/favicon.png"> -->

    <title><?php echo $this->config->item('website_name');?> Account Sign Up</title>

    <!-- Icons -->
    <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/simple-line-icons.css" rel="stylesheet">

    <!-- Main styles for this application -->
    <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">

</head>

<body class="app flex-row align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card-group mb-0">
                    <div class="card p-4">
                        <div class="card-block">
                            <h5 class="text-center">Register Account</h5>
                            <hr>
                            <span id="form_message"></span>
                            <form id="gen_form" method="post" action="<?php echo signup_url();?>">
                                <div class="input-group mb-3">
                                    <span class="input-group-addon"><i class="icon-user"></i>
                                    </span>
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
                                    <input name="email" type="email" class="form-control" placeholder="Email" required>
                                </div>
                                <div class="input-group mb-4">
                                    <span class="input-group-addon"><i class="icon-user"></i>
                                    </span>
                                    <input name="first_name" type="text" class="form-control" placeholder="First name">
                                </div>
                                <div class="input-group mb-4">
                                    <span class="input-group-addon"><i class="icon-user"></i>
                                    </span>
                                    <input name="last_name" type="text" class="form-control" placeholder="Last name">
                                </div>
                                <div class="input-group mb-4">
                                    <span class="input-group-addon"><i class="icon-lock"></i>
                                    </span>
                                    <input name="password" type="password" class="form-control" placeholder="Password" required>
                                </div>
                                <div class="input-group mb-4">
                                    <span class="input-group-addon"><i class="icon-lock"></i>
                                    </span>
                                    <input name="confirm_password" type="password" class="form-control" placeholder="Confirm Password" required>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <button id="gen_submit" type="submit" class="btn btn-primary px-4">Sign Up</button>
                                    </div>
                                    <div class="col-6 text-right">
                                        <a href="<?php echo login_url();?>" class="btn btn-link px-0">Back to Login</a>
                                    </div>
                                </div>
                               </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap and necessary plugins -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/tether/dist/js/tether.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/custom.js"></script>
</body>

</html>