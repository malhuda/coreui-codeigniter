<?php
defined('BASEPATH') or die();
class Admin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		if($this->user_model->logged_in() == false)
		{
			redirect(login_url());
		}
	}

	public function index()
	{
		$data = array(
			'user' => $this->user_model->userinfo(),
			'page' => false
		);
		$this->load->view('backend/main', $data);
	}

	/* Website settings */
	public function settings()
	{
		if($this->input->post())
		{
			$ret = array();
			if(is_protected('Admin') == false)
			{
				$ret['status'] = false;
				$ret['message'] = '<div class="alert alert-danger">You don\'t have permission to perform this action</div>'; 
			} else
			{
				foreach($this->input->post() as $name => $value)
				{
					$value = $this->security->xss_clean($value);
					$this->site_model->update_setting($name, $value);
				}
				$ret['status'] = true;
				$ret['message'] = '<div class="alert alert-success">Settings saved successfully</div>'; 
			}
			return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode($ret, JSON_PRETTY_PRINT));
		} else
		{
			if(is_protected('Admin'))
			{
				$data = array(
					'user' => $this->user_model->userinfo(),
					'page' => 'Website Settings'
				);
				$this->load->view('backend/web_settings', $data);
			} else
			{
				is_protected('Admin', true);
			}
		}
	}

	public function users()
	{
		if($this->input->post())
		{

		} else
		{
			if(is_protected('Admin'))
			{
				$data = array(
					'user' => $this->user_model->userinfo(),
					'users' => $this->user_model->get_all_users(),
					'page' => 'Manage Users'
				);
				$this->load->view('backend/manage_users', $data);
			} else
			{
				is_protected('Admin', true);
			}
		}
	}

	public function delete_all_users($id = false)
	{
		if($id)
		{
			$this->user_model->delete_user($id);
		} else
		{
			$this->user_model->delete_users();
		}
	}

	public function profile($id = false)
	{
		if(profile_editable($id))
		{
			$profile = false;
			$user = $this->user_model->userinfo();
			if($id)
			{
				if(is_protected('Admin'))
				{
					$id = (integer) $id;
					$profile = $this->user_model->userinfo($id);
				}
			} else
			{
				$profile = $user;
			}

			if($this->input->post())
			{
				$data = array();
				foreach($_POST as $key => $val)
				{
					if($key != 'user_id')
					{
						$data[$key] = $this->security->xss_clean($val);
					}
				}
				$id = $this->security->xss_clean($this->input->post('user_id'));
				$this->user_model->update_user($id, $data);
			} else
			{
				$data = array(
					'page' => 'Edit Profile',
					'profile' => $profile,
					'myself' => ($profile && $profile->uid == $user->uid) ? true : false,
					'user' => $user,
					'roles' => $this->user_model->get_roles()
				);
				if($profile)
				{
					$this->load->view('backend/profiles/profile', $data);
				} else
				{
					is_protected('Admin', true, true);
				}
			}
		} else
		{
			is_protected('Admin', true, true);
		}
	}

	public function add_user()
	{
		if($this->input->post())
		{
			if($this->user_model->userinfo()->is_admin)
			{
				$add = $this->user_model->add_user(false, true);
			} else
			{
				$ret = array('status' => false, 'message' => '<div class="alert alert-danger">You dont\'t have the permission to add a new user</div>');
				return $this->output
					->set_content_type('application/json')
					->set_status_header(200)
					->set_output(json_encode($ret, JSON_PRETTY_PRINT));
			}
		} else
		{
			if(is_protected('Admin'))
			{
				$data = array(
					'user' => $this->user_model->userinfo(),
					'page' => 'Add User',
					'roles' => $this->user_model->get_roles()
				);
				$this->load->view('backend/profiles/add_user', $data);
			} else
			{
				is_protected('Admin', true);
			}
		}
	}
}