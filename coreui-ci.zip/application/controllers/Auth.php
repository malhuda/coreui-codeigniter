<?php
defined('BASEPATH') or die();
class Auth extends CI_Controller
{

	public function logout()
	{
		$this->user_model->logout();
		redirect(login_url());
	}

	public function index()
	{
		redirect(login_url());
	}

	public function login()
	{
		handle_auth_redirect();
		if($this->input->post())
		{
			$this->user_model->authenticate($this->input->post('email'), $this->input->post('password'));
		} else
		{
			$this->load->view('backend/login');
		}
	}

	public function reset()
	{
		handle_auth_redirect();
		if($this->input->post())
		{
			switch($this->input->post('form_name'))
			{
				case 'reset_request':
					$this->user_model->password_reset_request($this->input->post('email'));
				break;
				case 'set_new_password':
					$this->user_model->set_new_password();
				break;
			}
		} elseif($this->input->get())
		{
			$token = $this->security->xss_clean($this->input->get('token'));
			$user_id = $this->security->xss_clean($this->input->get('aid'));
			if($this->user_model->verify_token($token, $user_id))
			{
				$this->load->view('backend/new_password');
			} else
			{
				$this->load->view('backend/wrong_token');
			}
		} else
		{
			$this->load->view('backend/reset');
		}
	}

	public function verify($resend = false)
	{
		handle_auth_redirect();
		if($resend)
		{
			$this->user_model->resend_auth_code();
			exit;
		}
		if(!$this->user_model->auth_initiated())
		{
			redirect(login_url());
		}

		if($this->input->post())
		{
			$this->user_model->twostep_authenticate($this->input->post('twostep_code'));
		} else
		{
			$this->load->view('backend/verify');
		}
	}

	public function register()
	{
		handle_auth_redirect();
		if($this->input->post())
		{
			$this->user_model->add_user();
		} else
		{
			$this->load->view('backend/register');
		}
	}

	public function activate()
	{
		handle_auth_redirect();
		$token = $this->security->xss_clean($this->input->get('token'));
		$user_id = $this->security->xss_clean($this->input->get('aid'));
		if($this->user_model->verify_token($token, $user_id))
		{
			$activate = $this->user_model->activate_account($user_id);
			if($activate)
			{
				$this->session->set_flashdata('flash_msg', 'Your account has been successfully activated. Sign in now.');
				$this->session->set_flashdata('flash_title', 'Account Activated');
				$this->session->set_flashdata('flash_icon', 'fa-check-circle');
				$this->session->set_flashdata('flash_color', 'green');
				redirect(login_url());
			} else
			{
				echo 'Account activation failed. Please contact admins';
			}
		} else
		{
			echo 'Activation link is either expired or invalid';
		}
	}
}