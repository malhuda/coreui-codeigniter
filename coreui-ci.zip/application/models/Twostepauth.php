<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Twostepauth extends CI_Model
{
	public function make_token($length = 6)
	{
		$result = '';
		for($i = 0; $i < $length; $i++) {
			$result .= mt_rand(0, 9);
		}
		return $result;
	}

	function twostep_init($to, $code = false)
	{
		$ret = array('status' => false);
		$bodymessage = 'Your 2-step verification code for '.get_setting('website_name').' is ';
		if($code == false)
		{
			$code = $this->make_token();
			$insert = array('twostep_code' => $code, 'mobile_number' => $to);
			$this->db->insert('twostep_codes', $insert);
			$lastID = $this->db->insert_id();
		} else
		{
			$lastID = false;
		}
		$id = get_setting('sid');
		$token = get_setting('auth_token');
		$url = "https://api.twilio.com/2010-04-01/Accounts/$id/SMS/Messages/";
		$from = get_setting('twilio_number');
		$body = $bodymessage . $code;
		$data = array (
		    'From' => $from,
		    'To' => $to,
		    'Body' => $body,
		);
		$post = http_build_query($data);
		$x = curl_init($url );
		curl_setopt($x, CURLOPT_POST, true);
		curl_setopt($x, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($x, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($x, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($x, CURLOPT_USERPWD, "$id:$token");
		curl_setopt($x, CURLOPT_POSTFIELDS, $post);
		$res = curl_exec($x);
		$res = simplexml_load_string($res);
		$status = (string) $res->SMSMessage->Status;
		if($status == 'queued')
		{
			$ret['status'] = true;
			$ret['id'] =  $lastID;
		}
		return (object) $ret;
	}

	function code_exists($id)
	{
		$exists = $this->db->where('id', $id)->get('twostep_codes');
		return $exists->num_rows() ? $exists : false;
	}

	function resend_code($id)
	{
		$exists = $this->code_exists($id);
		if($exists)
		{
			$this->twostep_init($exists->row('mobile_number'), $exists->row('twostep_code'));
		}
	}

	function verify_code($id, $code, $delete = false)
	{
		$where = array('id' => $id, 'twostep_code' => $code);
		$query = $this->db->where($where)->get('twostep_codes');
		$status = $query->num_rows() > 0 ? true : false;
		if($delete && $status) $this->db->where('id', $id)->delete('twostep_codes');
		return $status;
	}
}