<?php
defined('BASEPATH') or die();
class User_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('twostepauth');
	}

	public function password_reset_request($email, $first_password_set = false)
	{
		$user = $this->db->where('email', $email)->get('users');
		if($user->num_rows())
		{
			$token = $this->get_token($user->row('id'));
			if($first_password_set == true)
			{
				$subject = 'Your '. get_setting('website_name') . ' Account is Ready';
				$firstP = 'Your account at ' . get_setting('website_name'). ' has been created. You can set your account password by clicking the link below:';
				$lastP = 'This link will expire within 24 hours from now. If you feel that you have received this email in error and it doesn\'t belong to you, then please inform '.get_setting('website_name'). ' administration as soon as possible.<br><br>Sincerely,<br><strong>'.get_setting('website_name'). ' Team</strong>';
				$ctaLabel = 'Set Password';
			} else
			{
				$subject = 'Password Reset for Your '. get_setting('website_name') . ' Account';
				$ctaLabel =  'Reset Password';
				$firstP = 'Recently you requested the password reset for your account at ' . get_setting('website_name'). '. You can reset your account password by clicking the link below:';
				$lastP = 'This link will expire within 24 hours from now. If you did not request this reset link and have received this in error, please inform '.get_setting('website_name'). ' administration as soon as possible.<br><br>Sincerely,<br><strong>'.get_setting('website_name'). ' Team</strong>';
			}
			$temp_data = array(
				'name' => $user->row('first_name'),
				'cta_link' => reset_url().'?token='.$token.'&aid='.$user->row('id'),
				'cta_label' => $ctaLabel,
				'first_paragraph' => $firstP,
				'last_paragraph' => $lastP
			);
			$email_template = $this->load->view('backend/emails/basic', $temp_data, true);
			$this->load->model('email_model');
			$send = $this->email_model->send($user->row('email'), $subject, $email_template);
			if($first_password_set == true)
			{
				if($send)
				{
					return true;
				} else
				{
					return false;
				}
			}
		} else
		{
			$ret = array('status' => false, 'message' => '<div class="alert alert-warning">Account does not exist</div>');
		}
		return send_json($ret);
	}

	public function get_token($user_id, $purpose = 'password_reset')
	{
		$this->delete_expired_tokens();
		$where = array('user_id' => $user_id, 'purpose' => $purpose);
		$check = $this->db->where($where)->get('auth_tokens');
		if($check->num_rows())
		{
			$this->db->where('id', $check->row('id'))->update('auth_tokens', array('created_on' => date("Y-m-d H:i:s")));
			$token = $check->row('token');
		} else
		{
			$token = getToken(100);
			$this->db->insert('auth_tokens', array('user_id' => $user_id, 'token' => $token, 'purpose' => $purpose));
		}
		return $token;
	}

	public function set_new_password()
	{
		if($this->session->resetaccount)
		{
			$user = $this->userinfo($this->session->resetaccount);
			if($user)
			{
				$this->load->library('form_validation');
				$this->form_validation->set_rules('password', 'password', 'required|min_length[5]', array('min_length' => 'Password too short'));
				$this->form_validation->set_rules('confirm_password', 'Password Confirmation', 'required|matches[password]', array('matches' => 'The passwords did not match'));
				if($this->form_validation->run() == FALSE)
				{
					$ret = array('success' => false, 'message' => validation_errors('<div class="alert alert-danger">', '</div>'));
				} else
				{
					$password = $this->input->post('password');
					$this->db->where('id', $this->session->resetaccount)->update('users', array('password' => password_hash($password, PASSWORD_DEFAULT)));
					$this->delete_token($this->session->resetaccount);
					$this->session->resetaccount = null;
					$ret = array('success' => true, 'message' => '<div class="alert alert-success">Password updated, <a href="'.login_url().'">sign in now</a></div>');
				}
			} else
			{
				$ret = array('status' => true, 'message' => '<div class="alert alert-warning">Request failed</div>', 'url' => login_url());
			}
		}
		return $this->output
			->set_content_type('application/json')
			->set_status_header(200)
			->set_output(json_encode($ret, JSON_PRETTY_PRINT));
	}

	public function activate_account($user_id)
	{
		if($this->session->resetaccount == $user_id)
		{
			$this->db->where('id', $user_id)->update('users', array('is_active' => 1));
			if($this->db->affected_rows() > 0)
			{
				$this->delete_token($user_id, 'account_activation');
				$this->session->resetaccount = null;
				return true;
			}
		}
		return false;
	}

	public function delete_token($user_id, $purpose = 'password_reset')
	{
		$where = array('user_id' => $user_id, 'purpose' => $purpose);
		$this->db->where($where)->delete('auth_tokens');
	}

	public function verify_token($token, $user_id)
	{
		$where = array('user_id' => $user_id, 'token' => $token);
		$check = $this->db->where($where)->get('auth_tokens');
		$this->session->resetaccount = $user_id;
		return $check->num_rows() ? true : false;
	}

	public function delete_expired_tokens()
	{
		$where = 'created_on < (NOW() - INTERVAL 1 DAY)';
		$this->db->where("$where")->delete('auth_tokens');
	}

	public function authenticate($email, $password)
	{
		$ret = array();
		$ret['status'] = false;
		$ret['message'] = '<div class="alert alert-danger">Login is invalid</div>';
		$user = $this->db->where('email', $email)->get('users');
		if($user->num_rows())
		{
			if($user->row('is_active') == false)
			{
				$ret['status'] = false;
				$ret['message'] = '<div class="alert alert-danger">This account is currently inactive</div>';
			} else
			{
				$passok = password_verify($password, $user->row('password'));
				$user_id = $user->row('id');
				if($this->two_step_enabled($user->row('id')))
				{
					if($passok)
					{
						$mobile = $user->row('mobile_number');
						if($mobile)
						{
							$authsent = $this->twostepauth->twostep_init($mobile);
							if($authsent->status == true)
							{
								$this->session->authid = $authsent->id;
								$this->session->mobnum = str_pad(substr($mobile, -4), strlen($mobile), '*', STR_PAD_LEFT);
								$this->session->userid = $user->row('id');
								$ret['status'] = true;
								$ret['message'] = '';
								$ret['url'] = verify_url();
							} else
							{
								$ret['status'] = false;
								$ret['message'] = '<div class="alert alert-danger">2-step api error, please inform admins</div>';
							}
						} else
						{
							$ret['status'] = false;
							$ret['message'] = '<div class="alert alert-warning">Mobile number not set. Sign in blocked</div>';
						}
					} else
					{
						$ret['status'] = false;
						$ret['message'] = '<div class="alert alert-danger">Login is invalid</div>';
					}
				} else
				{
					if($passok)
					{
						$this->session->userdata['signed_in'] = $user_id;
						$ret['status'] = true;
						$ret['message'] = '<div class="alert alert-success">Login validated</div>';
						$ret['url'] = admin_url();
					}
				}
			}
		}
		return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode($ret, JSON_PRETTY_PRINT));
	}

	public function twostep_authenticate($code)
	{
		$ret = array('status' => false, 'message' => '<div class="alert alert-danger">2-step auth code is invalid</div>');
		if($this->auth_initiated())
		{
			$id = $this->session->authid;
			if($this->twostepauth->verify_code($id, $code, true))
			{
				$this->session->userdata['signed_in'] = $this->session->userid;
				$this->session->userid = null;
				$this->session->authid = null;
				$this->session->mobnum = null;
				$ret['status'] = true;
				$ret['message'] = '';
				$ret['url'] = admin_url();
			}
		}
		return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode($ret, JSON_PRETTY_PRINT));
	}

	public function auth_initiated()
	{
		$ret = false;
		if($this->session->authid)
		{
			$id = $this->session->authid;
			$ret = $this->twostepauth->code_exists($id);
		}
		return $ret;
	}

	public function logout()
	{
		$this->session->userdata['signed_in'] = null;
	}

	public function userinfo($id = false)
	{
		if(!$id)
		{
			$id = $this->session->userdata('signed_in');
		}
		if($id)
		{
			$user = $this->db->select('*, users.id as uid, roles.id as rid')->from('users')->join('roles', 'users.role = roles.id')->where('users.id', $id)->get();
			if($user->num_rows())
			{
				$info = $user->row();
				$info->id = $user->row('uid');
				$info->is_admin = $info->role_name == 'Admin' ? true : false;
				$info->full_name = $user->row('first_name') . ' ' . $user->row('last_name');
				$info->has_power = ($info->is_admin) ? true : false;
				$info->avatar_url = 'https://www.gravatar.com/avatar/'.md5($user->row('email')).'fs=100';
				return $info;
			}
		}
		return false;
	}

	public function add_meta($id, $data)
	{
		$ret = array('status' => false, 'message' => '<div class="alert alert-danger">You don\'t have permission to perform this action</div>');
		if($this->logged_in() == true)
		{
			if($this->userinfo()->is_admin == true || $id == $this->userinfo()->uid)
			{
				foreach($data as $key => $value)
				{
					$id = (integer) $this->security->xss_clean($id);
					$key = $this->security->xss_clean($key);
					$value = $this->security->xss_clean($value);
					if($this->get_meta($id, $key))
					{
						$ret['status'] = false;
						$ret['message'] = '<div class="alert alert-danger">Meta key <strong>'.$key.'</strong> exists</div>';
					} else
					{
						$insert = array('user_id' => $id, 'meta_key' => $key, 'meta_value' => $value);
						$this->db->insert('user_meta', $insert);
						$ret['status'] = true;
						$ret['id'] = $this->db->insert_id();
						$ret['message'] = 'Meta info added successfully';
					}
				}
			}
		}
		return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode($ret, JSON_PRETTY_PRINT));
	}

	public function udpate_meta($id, $data)
	{
		$ret = array('status' => false, 'message' => '<div class="alert alert-danger">You don\'t have permission to perform this action</div>');
		if($this->logged_in() == true)
		{
			if($this->userinfo()->is_admin == true || $id == $this->userinfo()->uid)
			{
				foreach($data as $key => $value)
				{
					$id = (integer) $this->security->xss_clean($id);
					$key = $this->security->xss_clean($key);
					$value = $this->security->xss_clean($value);
					if(!$this->get_meta($id, $key))
					{
						$ret['status'] = false;
						$ret['message'] = '<div class="alert alert-danger">Meta key <strong>'.$key.'</strong> does not exist</div>';
					} else
					{
						$where = array('meta_key' => $key, 'user_id' => $id);
						$this->db->where($where)->update('user_meta', array('meta_value' => $value));
						$ret['status'] = true;
						$ret['message'] = 'Meta info updated successfully';
					}
				}
			}
		}
		return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode($ret, JSON_PRETTY_PRINT));
	}

	public function get_meta($id, $key)
	{
		$where = array('user_id' => $id, 'meta_key' => $key);
		$meta = $this->db->where($where)->get('user_meta');
		if($meta->num_rows())
		{
			return $meta->row('meta_value');
		} else
		{
			return false;
		}
	}

	public function reg_allowed()
	{
		if($this->is_admin())
		{
			return true;
		} else
		{
			if(get_setting('allow_registrations') == 'yes')
			{
				return true;
			}
		}
		return false;
	}

	public function get_all_users($cond = false)
	{
		if(is_array($cond))
		{
			$this->db->where($cond);
		}
		$users = $this->db->get('users');
		$results = $users->num_rows() ? $users->result() : false;
		$ret = false;
		if($results)
		{
			$ret = array();
			foreach($results as $result)
			{
				$ret[] = $this->userinfo($result->id);
			}
		}
		return $ret;
	}

	public function is_admin()
	{
		if(is_auth() && $this->userinfo()->is_admin)
		{
			return true;
		}
		return false;
	}

	public function verification_required()
	{
		if(!$this->is_admin() && get_setting('email_verification_required') == 'yes')
		{
			return true;
		}
	}

	public function add_user($data = false, $manual = false)
	{
		// Return data container
		$ret = array();

		if($manual == true)
		{
			$ps = getToken(10);
			$_POST['password'] = $ps;
			$_POST['confirm_password'] = $ps;
		}
		if($this->reg_allowed())
		{
			$this->load->library('form_validation');
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]', array('required' => 'Email is reauired', 'valid_email' => 'Email is invalid', 'is_unique' => 'Email is already taken'));
			$this->form_validation->set_rules('first_name', 'First name', 'required', array('required' => 'First name is required'));
			$this->form_validation->set_rules('last_name', 'Last name', 'required', array('required' => 'Last name is required'));
			$this->form_validation->set_rules('password', 'password', 'required|min_length[5]', array('min_length' => 'Password too short'));
			$this->form_validation->set_rules('confirm_password', 'Password Confirmation', 'required|matches[password]', array('matches' => 'The passwords did not match', 'required' => 'Password confirmation required'));
			if($this->form_validation->run() == FALSE)
			{
				$ret = array('success' => false, 'message' => validation_errors('<div class="alert alert-danger">', '</div>'));
			} else
			{
				$data = array();
				$insert = array('email', 'first_name', 'last_name', 'mobile_number', 'password', 'role', 'bio');
				foreach($_POST as $key => $val)
				{
					if(in_array($key, $insert))
					{
						$data[$key] = $this->security->xss_clean($val);
						if($key == 'password')
						{
							$data['password'] = password_hash($val, PASSWORD_DEFAULT);
						}
					}
				}
				if($manual = true)
				{
					$verify_email = false;
				} else
				{
					$verify_email = $this->verification_required();
				}

				if($verify_email)
				{
					$data['is_active'] = 0;
				}
				if(!filter_var($data['role'], FILTER_VALIDATE_INT))
				{
					$data['role'] = $this->get_roleid_by_name('User');
				}
				$this->db->insert('users', $data);
				$user_id = $this->db->insert_id();
				if($user_id)
				{
					$ret['status'] = true;
					$ret['message'][] = '<div class="alert alert-success">Registration successful</div>';
					if($verify_email)
					{
						$token = $this->get_token($user_id, 'account_activation');
						$temp_data = array(
							'name' => $data['first_name'],
							'cta_link' => acc_verify_url().'?token='.$token.'&aid='.$user_id,
							'cta_label' => 'Activate Account',
							'first_paragraph' => 'Thank you for creating an account at ' . get_setting('website_name'). '. You are one step away from activating your account. Here is the URL for your account activation:',
							'last_paragraph' => 'This link will expire within 24 hours from now. If you did not sign up at our website, then kindly notify '.get_setting('website_name'). ' administration.<br><br>Sincerely,<br><strong>'.get_setting('website_name'). ' Team</strong>'
						);
						$email_template = $this->load->view('backend/emails/basic', $temp_data, true);
						$this->load->model('email_model');
						$sendEmail = $this->email_model->send($data['email'], get_setting('website_name') . ' Account Activation', $email_template);
						if(!$sendEmail)
						{
							$ret['status'] = false;
							$ret['message'][] = '<div class="alert alert-danger">Verification email cannot be sent</div>';
							$this->delete_user($user_id);
						}
					}
					$ret['user_id'] = $user_id;
					if($manual)
					{
						// Send a password reset link to the user
						$sendEmail = $this->password_reset_request($data['email'], true);
						if(!$sendEmail)
						{
							$ret['status'] = false;
							$ret['message'] = '<div class="alert alert-danger">Verification email cannot be sent</div>';
							$this->delete_user($user_id);
						} else
						{
							// Redirect admin to user's profile page
							$ret['url'] = admin_url('profile/'.$user_id);
						}
					}
				} else
				{
					$ret['status'] = false;
					$ret['message'][] = '<div class="alert alert-warning">Unknown error occured</div>';
				}
			}
		} else
		{
			$ret['status'] = false;
			$ret['message'][] = '<div class="alert alert-danger">Registration is currently disabled</div>';
		}
		send_json($ret);
	}

	public function get_roles()
	{
		$roles = $this->db->get('roles');
		return $roles->num_rows() ? $roles->result() : false;
	}

	public function get_role_name_by_id($id)
	{
		$role = $this->db->where('id', $id)->get('roles');
		return $role->num_rows() ? $role->row('role_name') : false;
	}

	public function get_roleid_by_name($name)
	{
		$ret = 0;
		$role = $this->db->where('role_name', $name)->get('roles');
		if($role->num_rows())
		{
			$ret = $role->row('id');
		}
		return $ret;
	}

	public function update_user($id, $data)
	{
		// Return data container
		$ret = array();

		// Validate if user has permission to update
		if($this->logged_in() == true && profile_editable($id))
		{	
			$save = true;
			// If received data isn't an array, return false
			if(!is_array($data))
			{
				$ret['status'] = false;
				$save = false;
				$ret['messages'][] = 'Data is invalid. Must be a valid array for CI insert';
			}

			$profile = $this->userinfo($id);
			if(!$profile)
			{
				$save = false;
				$ret['message'] = '<div class="alert alert-danger">User profile does not exist</div>';
			}

			// Check if email is changed and available then update
			if($this->input->post('email'))
			{
				if($profile->email != $this->input->post('email') && $this->email_available(trim($this->input->post('email'))) == false)
				{
					$save = false;
					$ret['status'] = false;
					$ret['message'] = '<div class="alert alert-danger">Provided email address is already in use by another profile</div>';
				}
			}

			// Handle password
			$pass = (strlen(trim($this->input->post('password'))) > 5) ? $this->input->post('password') : false;
			if(!$pass)
			{
				unset($data['password']);
			}

			if($save == true)
			{
				// Loop through the $data, clean it and reconstruct the array
				foreach($data as $field => $value)
				{
					if($field != 'password')
					{
						$data[$field] = $this->security->xss_clean($value);
					}
				}

				// Trim whitespace from email
				$data['email'] = trim($data['email']);

				// Strip tags from bio
				$data['bio'] = strip_tags($data['bio']);

				// Add the ID of the admin who is currently updating the user
				$data['updated_by'] = user_id();

				// Hash the password if provided
				if(isset($data['password']))
				{
					$data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
				}
				
				$this->db->where('id', $id)->update('users', $data);
				$updated_rows = $this->db->affected_rows();
				if($updated_rows == 0)
				{
					$ret['status'] = false;
					$ret['message'] = '<div class="alert alert-warning">No details were updated</div>';
				} else
				{
					$ret['status'] = true;
					$ret['message'] = '<div class="alert alert-success">Profile details have been updated</div>';
				}
			}
		} else
		{
			$ret['status'] = false;
			$ret['message'] = '<div class="alert alert-warning">You don\'t have permission to perform this action</div>';
		}
		return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode($ret, JSON_PRETTY_PRINT));
	}

	public function delete_user($id)
	{
		$ret = array('status' => false, 'message' => 'You are not permitted to perform this action');
		if($this->logged_in() == true)
		{
			$usr = $this->userinfo($id);
			if($this->userinfo()->has_power == true)
			{
				if($id == $this->userinfo()->uid)
				{
					$ret['status'] = false;
					$ret['message'] = 'You cannot delete your own account';
				} else
				{
					$ret['status'] = true;
					$ret['message'] = 'User deleted';
					$this->db->where('id', $id)->delete('users');
					$this->db->where('user_id', $id)->delete('user_meta');
					$this->db->where('user_id', $id)->delete('team');
					$this->comments_model->delete_comments(array('user_id' => $id));
					$this->notif_model->delete_notifs(array('receiver_id' => $id));
					$this->notif_model->delete_notifs(array('sender_id' => $id));
					$this->project_model->update_project(array('manager_id' => $id), array('manager_id' => NULL));
					$this->project_model->update_project(array('owner_id' => $id), array('owner_id' => user_id()));
					$this->tasks_model->delete_tasks(array('user_id' => $id));
				}
			}
		}
		send_json($ret);
	}

	public function email_available($email)
	{
		$check = $this->db->where('email', $email)->get('users');
		return !$check->num_rows() ? true : false;
	}

	public function resend_auth_code()
	{
		$ret = array('status' => false);
		if($this->auth_initiated())
		{
			$this->twostepauth->resend_code($this->session->authid);
		}
	}

	public function logged_in()
	{
		$info = $this->userinfo();
		return $info == true ? true : false;
	}

	private function two_step_enabled($id)
	{
		$ret = false;
		if(get_setting('two_factor_auth') == 'yes')
		{
			if(get_setting('force_two_factor_auth') == 'yes')
			{
				$ret = true;
			} else
			{
				$twostep_enabled = $this->user_model->get_meta($id, 'twostep_auth');
				if($twostep_enabled == 'yes')
				{
					$ret = true;
				}
			}
		}
		return $ret;
	}

	public function delete_users()
	{
		$ret = array('status' => false, 'message' => 'You are not allowed to do this!');
		if($this->is_admin())
		{
			$where = array('id !=' => user_id());
			$users = $this->db->where($where)->get('users');
			if($users->num_rows())
			{
				$this->db->where($where)->delete('users');
				$affected = $this->db->affected_rows();
				$deleted = $affected > 0 ? $affected : false;
				// Delete data from user_meta table
				$this->db->where('user_id !=', user_id())->delete('user_meta');
				if($deleted)
				{
					$ret = array('status' => true, 'message' => 'All profiles deleted!');
				}
			} else
			{
				$ret = array('status' => false, 'message' => 'No user accounts found except yours!');
			}
		}
		return $this->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode($ret, JSON_PRETTY_PRINT));
	}
}