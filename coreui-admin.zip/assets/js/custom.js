$(document).on('submit', '#gen_form', function() {
	$('#form_message').html('');
	$('#gen_submit').addClass('disabled');
	$.post($(this).attr('action'), $(this).serialize(), function(data) {
		$('#gen_submit').removeClass('disabled');
		$('#form_message').html(data.message);
		if(data.url) {
			window.location = data.url;
		}
	});
	return false;
});

$(document).on('submit', '.settings_form', function() {
	$('.submitbtn').addClass('disabled');
	$.post($(this).attr('action'), $(this).serialize(), function(data) {
		$('.submitbtn').removeClass('disabled');
		$.alert({
			draggable: true,
			alignMiddle: true,
			offsetTop: 200,
			icon: 'fa fa-check-circle',
		  	title: 'Settings saved',
		  	type: 'green',
		  	content: 'All settings have been saved successfully.',
		});
	});
	return false;
});

$(document).on('change', '.selch', function() {
	$('.settings_form').submit();
	window.location = '';
});

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});

$(document).on('click', '#delete_all_users', function() {
	var theurl = $(this).data('url');
	$.confirm({
		title: 'Are you sure?',
		content: 'All user profiles (except you) will be deleted.',
		type: 'red',
		buttons: {   
			ok: {
				text: "Yes, Delete",
				btnClass: 'btn-danger',
				keys: ['enter'],
				action: function(){
					$.get(theurl, function(data) {
						if(data.status == true)
						{
							$('.other-users').fadeOut();
						} else
						{
							$.alert({
				            title: 'No profiles deleted!',
				            draggable: true,
				            alignMiddle: true,
				            offsetTop: 200,
				            type: 'red',
				            content: data.message,
				        });
						}
					});
				}
			},
			cancel: function() {
				
			}
		}
	});
});

$(document).on('click', '#user_reset_pass', function() {
	$.confirm({
		title: 'Are you sure?',
		content: 'A reset link will be emailed to '+$('#user_reset_pass').data('name'),
		type: 'red',
		buttons: {   
			ok: {
				text: "Yes, Reset",
				btnClass: 'btn-danger',
				keys: ['enter'],
				action: function(){
					var posturl = $('#user_reset_pass').data('url');
					var data = {'form_name': 'reset_request', 'email': $('#user_reset_pass').data('email'), 'auth_sec_token': $('#csrf_token').val()};
					$.post(posturl, data);
					$.alert({
				      title: 'Password reset initiated!',
				      draggable: true,
				      alignMiddle: true,
				      offsetTop: 200,
				      type: 'green',
				      content: 'Password reset link will be emailed shortly',
				  });
				}
			},
			cancel: function() {
				
			}
		}
	});
});

$(document).on('click', '.deleteuser', function() {
	var userid = $(this).data('id');
	var geturl = $(this).data('url');
	$.confirm({
		title: 'Are you sure?',
		content: 'The user account will be permanently deleted',
		type: 'red',
		buttons: {   
			ok: {
				text: "Yes, Delete",
				btnClass: 'btn-danger',
				keys: ['enter'],
				action: function() {
					$.get(geturl, function(data) {
						if(data.status == true) {
							$('#user-'+userid).fadeOut();
						} else {
							$.alert({
						      title: 'User cannot be deleted!',
						      draggable: true,
						      alignMiddle: true,
						      offsetTop: 200,
						      type: 'red',
						      content: data.message
						  });
						}
					});
				}
			},
			cancel: function() {
				
			}
		}
	});
});