<ol class="breadcrumb">
    <li class="breadcrumb-item">Home</li>
    <li class="breadcrumb-item"><a href="<?php echo site_url('admin');?>">Admin</a>
    </li>
    <li class="breadcrumb-item active"><?php echo $page;?></li>
</ol>