<nav class="sidebar-nav">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('admin');?>"><i class="icon-speedometer"></i> Dashboard</a>
        </li>
        <?php if(is_protected('Admin')):?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('admin/users');?>"><i class="icon-user"></i> Manage Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('admin/settings');?>"><i class="icon-settings"></i> Website Settigs</a>
        </li>
        <?php endif;?>
    </ul>
</nav>