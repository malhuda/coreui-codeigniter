<div class="col-sm-12">
	<div class="card">
		<div class="card-block">
			<form id="gen_form" method="post" action="<?php echo admin_url('add_user');?>">
				<h4>Add a User <i class="fa fa-user pull-right"></i></h4>
				<hr>
				<div class="row">
					<div class="form-group col-md-6">
						<label>First Name</label>
						<input id="csrf_token" type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
						<input type="text" name="first_name" class="form-control" placeholder="First name">
					</div>
					<div class="form-group col-md-6">
						<label>Last Name</label>
						<input type="text" name="last_name" class="form-control" placeholder="Last name">
					</div>
					<div class="form-group col-md-6">
						<label>Email</label>
						<input type="text" name="email" class="form-control" placeholder="Email">
					</div>
					<div class="form-group col-md-6">
						<label>Mobile Number</label>
						<input type="text" name="mobile_number" class="form-control" placeholder="Mobile number">
					</div>
					<div class="form-group col-md-6">
						<label>User Role</label>
						<select class="form-control" name="role" required>
							<?php if(is_array($roles)): foreach($roles as $role):?>
								<option value="<?php echo $role->id;?>"><?php echo $role->role_name;?></option>
							<?php endforeach; else:?>
							<option value="" class="disabled">No roles found</option>
							<?php endif;?>
						</select>
					</div>
					<div class="form-group col-md-6">
						<label>User Status</label>
						<select class="form-control" name="is_active" required>
							<option value="1">Active</option>
							<option value="0">Inactive</option>
						</select>
					</div>
					<div class="form-group col-md-12">
						<label>Bio Info</label>
						<textarea rows="4" class="form-control" name="bio" placeholder="Brief profile biography (Optional)"></textarea>
					</div>
					<div class="form-group col-md-12">
						<i>A password reset link will be emailed to the user once you add them so the user can set a password for their account.</i>
					</div>
					<div class="col-md-12" id="form_message"></div>
					<div class="form-group col-md-12 text-right">
						<button id="gen_submit" class="btn btn-info">Add User</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>