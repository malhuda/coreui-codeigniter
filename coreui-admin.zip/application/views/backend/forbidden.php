<html lang="en">
<?php $this->load->view('backend/partials/head');?>
<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
    <?php $this->load->view('backend/partials/header');?>
    <div class="app-body">
        <div class="sidebar">
           <?php $this->load->view('backend/partials/sidebar');?>
        </div>
        <!-- Main content -->
        <main class="main">
            <!-- Breadcrumb -->
            <?php $this->load->view('backend/partials/breadcrumb');?>

            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <br><br><br>
                        <div class="clearfix text-center">
                            <h1 class="text-danger display-3 mr-4">403</h1>
                            <h5 class="text-danger">You don't have permissions to access this content!</h5>
                            <hr>
                            <p class="text-muted">This means that either you don't have necessary rights to access the content on this page or it doesn't exist. If you have doubts and think that your access is blocked to a valid page in error, then you should contact website admins regarding this incident.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.conainer-fluid -->
        </main>
    </div>
    <?php $this->load->view('backend/partials/footer');?>
</body>

</html>