<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- <link rel="shortcut icon" href="assets/ico/favicon.png"> -->

    <title><?php echo $this->config->item('website_name');?> Admin Login Area</title>

    <!-- Icons -->
    <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/simple-line-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.2.3/jquery-confirm.min.css">
    <!-- Main styles for this application -->
    <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">

</head>

<body class="app flex-row align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-<?php echo reg_enabled() ? '8' : '4';?>">
                <div class="card-group mb-0">
                    <div class="card p-4">
                        <div class="card-block">
                            <h4>Account Login</h4>
                            <hr>
                            <p class="text-muted">Sign In to your account</p>
                            <span id="form_message"></span>
                            <form id="gen_form" method="post" action="<?php echo login_url();?>">
                                <div class="input-group mb-3">
                                    <span class="input-group-addon"><i class="icon-user"></i>
                                    </span>
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
                                    <input name="email" type="email" class="form-control" placeholder="Email">
                                </div>
                                <div class="input-group mb-4">
                                    <span class="input-group-addon"><i class="icon-lock"></i>
                                    </span>
                                    <input name="password" type="password" class="form-control" placeholder="Password">
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <button id="gen_submit" type="submit" class="btn btn-primary px-4">Login</button>
                                    </div>
                                    <div class="col-6 text-right">
                                        <a href="<?php echo reset_url();?>" class="btn btn-link px-0">Forgot password?</a>
                                    </div>
                                </div>
                               </form>
                        </div>
                    </div>
                    <?php if(reg_enabled()):?>
                    <div class="card card-inverse card-primary py-5 d-md-down-none" style="width:44%">
                        <div class="card-block text-center">
                            <div>
                                <h2>Sign up</h2>
                                <p>Don't have an account yet? You can sign up now. Account registration is straightforward and simple and it will take under a minute.</p>
                                <a href="<?php echo signup_url();?>"><button type="button" class="btn btn-primary active mt-3">Register Now!</button></a>
                            </div>
                        </div>
                    </div>
                    <?php endif;?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap and necessary plugins -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/tether/dist/js/tether.min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.2.3/jquery-confirm.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/custom.js"></script>
    <?php if($this->session->flashdata('flash_msg')):?>
    <script>
        $.alert({
            icon: 'fa <?php echo $this->session->flashdata('flash_icon');?>',
            title: '<?php echo $this->session->flashdata('flash_title');?>',
            type: '<?php echo $this->session->flashdata('flash_color');?>',
            draggable: true,
            alignMiddle: true,
            offsetTop: 200,
            content: '<?php echo $this->session->flashdata('flash_msg');?>',
        });
    </script>
    <?php endif;?>
</body>

</html>