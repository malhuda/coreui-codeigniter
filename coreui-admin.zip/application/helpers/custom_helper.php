<?php
function is_protected($req_role = 'Admin', $show_forbidden = false, $force_show_forbidden = false)
{
	$ci =& get_instance();
	if($force_show_forbidden == true)
	{
		$data = array('user' => $ci->user_model->userinfo(), 'page' => '');
		$ci->load->view('backend/forbidden', $data);
	} else
	{
		if($ci->user_model->userinfo()->has_power)
		{
			$checked = true;
		} else
		{
			$checked = $req_role == $ci->user_model->userinfo()->role_name ? true : false;
		}
		if($show_forbidden)
		{
			if(!$checked)
			{
				$data = array('user' => $ci->user_model->userinfo(), 'page' => '');
				$ci->load->view('backend/forbidden', $data);
			}
		} else
		{
			return $checked;
		}
	}
}

function reset_url()
{
	return site_url('auth/reset');
}

function signup_url()
{
	return site_url('auth/register');
}

function show_setting($name)
{
	$ci =& get_instance();
	$return = true;
	$setting = $ci->db->where('setting_name', $name)->get('website_settings');
	if($setting->row('linked'))
	{
		$linked = $ci->db->where('setting_name', $setting->row('linked'))->get('website_settings');
		if($linked->row('setting_value') == 'no')
		{
			$return = false;
		}
	}
	return $return;
}

function is_auth()
{
	$ci =& get_instance();
	return $ci->user_model->logged_in() ? true : false;
}

function get_setting($name)
{
	$ci =& get_instance();
	return $ci->site_model->get_setting($name);
}

function get_all_settings($group = false)
{
	$ci =& get_instance();
	if($group)
	{
		$ci->db->where('setting_group', $group);
	}
	return $ci->site_model->get_all_settings();
}

function reg_enabled()
{
	if(get_setting('allow_registrations') == 'yes')
	{
		return true;
	} else
	{
		return false;
	}
}

function acc_verify_url()
{
	return site_url('auth/activate');
}

function login_url()
{
	return site_url('auth/login');
}

function admin_url($append = '')
{
	return site_url('admin/'.$append);
}

function verify_url($append = '')
{
	return site_url('auth/verify/'.$append);
}

function crypto_rand_secure($min, $max)
{
    $range = $max - $min;
    if ($range < 1) return $min; // not so random...
    $log = ceil(log($range, 2));
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd > $range);
    return $min + $rnd;
}

function role_name_by_id($id = false)
{
	$ci =& get_instance();
	$role = $ci->user_model->get_role_name_by_id($id);
	return $role ? $role : '<i>Not set</i>';
}

function user_id()
{
	if(is_auth())
	{
		$ci =& get_instance();
		return $ci->user_model->userinfo()->uid;
	} else
	{
		return null;
	}
}

function is_switched()
{
	$ci =& get_instance();
	return ($ci->session->userswitch == true) ? true : false;
}

function profile_editable($id = false)
{
	$ci =& get_instance();
	if(get_setting('users_can_edit_their_profiles') && $id == user_id())
	{
		return true;
	} else
	{
		if($ci->user_model->userinfo()->has_power)
		{
			return true;
		}
	}
	return false;
}

function handle_auth_redirect()
{
	$ci =& get_instance();
	if(is_auth())
	{
		if($ci->input->is_ajax_request())
		{
			$ret = array('status' => false, 'message' => '', 'url' => admin_url());
			return $ci->output
				->set_content_type('application/json')
				->set_status_header(200)
				->set_output(json_encode($ret, JSON_PRETTY_PRINT));
		} else
		{
			redirect(admin_url());
		}
	}
}
 
function getToken($length = 30)
{
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    $max = strlen($codeAlphabet); // edited
 
    for ($i=0; $i < $length; $i++) {
        $token .= $codeAlphabet[crypto_rand_secure(0, $max-1)];
    }
 
    return $token;
}