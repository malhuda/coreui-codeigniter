<?php
defined('BASEPATH') or die();
class Email_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('email');
		if(strtolower(get_setting('email_type')) == 'html')
		{
			$this->email->set_mailtype("html");
		}
	}

	public function send($to, $subject, $message)
	{
		$this->email->from(get_setting('from_email'), get_setting('website_name'));
		$this->email->to($to);
		$this->email->subject($subject);
		$this->email->message($message);
		$this->email->send();
	}
}