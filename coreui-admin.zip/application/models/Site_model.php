<?php
defined('BASEPATH') or die();
class Site_model extends CI_Model
{
	public function get_setting($name)
	{
		$setting = $this->db->where('setting_name', $name)->get('website_settings');
		if($setting->num_rows())
		{
			return $setting->row('setting_value');
		} else
		{
			return false;
		}
	}

	public function get_all_settings()
	{
		$results = $this->db->get('website_settings')->result();
		return $results ? $results : false;
	}

	public function update_setting($name, $value)
	{
		$this->db->where('setting_name', $name)->update('website_settings', array('setting_value' => $value));
	}
}